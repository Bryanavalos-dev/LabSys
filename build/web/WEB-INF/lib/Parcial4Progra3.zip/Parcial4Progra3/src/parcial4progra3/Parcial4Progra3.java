/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial4progra3;

import Formularios.empleados;

/**
 *
 * @author gerson
 */
public class Parcial4Progra3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        empleados emp = new empleados();
        emp.setVisible(true);
    }
    
}
